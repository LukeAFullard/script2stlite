"""
script2stlite - Convert Streamlit scripts to stlite HTML files
"""

__version__ = "0.1.0"  # Placeholder version

from .script2stlite import Script2StliteConverter

__all__ = ["Script2StliteConverter"]
